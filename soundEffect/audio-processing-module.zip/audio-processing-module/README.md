# Audio-Processing-Module
audio-processing-module is extracted from WebRTC.
including the AEC,NS,VAD,CNG function.

# Build
- build partion
1. cd independent_xxx
2. mkdir build
3. cd build
4. cmake ..
5. make
---
- build all
1. mkdir build
2. cd build
3. cmake ..
4. make

# Git Origin Repository
url = git@github.com:zhang-ray/audio-processing-module.git



