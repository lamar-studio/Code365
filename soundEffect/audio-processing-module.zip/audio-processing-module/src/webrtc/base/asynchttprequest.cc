// TODO(pthatcher): Remove this file once chromium's GYP file doesn't
// refer to it.
